

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'index_controller.dart';
import 'item_widget.dart';

class HoleWidget extends StatefulWidget{
  IndexController indexController;
  int _selectedIndex;

  HoleWidget({IndexController indexController,int selectedIndex}):indexController = indexController,_selectedIndex = selectedIndex;

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _HoleWidgetState();
  }

}


class _HoleWidgetState extends State<HoleWidget>{

  @override
  void initState() {
    widget.indexController.setSelectedIndex(widget._selectedIndex);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children:createChildren(),
    );
  }

  List<Widget> createChildren(){
    int selectedIndex = 0;

    List<Widget> _widgets = [];
    for(int i = 0; i< 10; i++){
//      Widget child,
//  {IndexChangeNotifier valueChangeNotifier, int index, int selectedIndex}
      Widget subWidget = ItemWidget(indexController:widget.indexController, index: i, selectedIndex:selectedIndex,
          child:
          Container(
            padding: EdgeInsets.all(20),
            child: Text('index = $i'),
          )
      );
      _widgets.add(subWidget);
    }
    return _widgets;
  }

  Color _getColor(int i){
    if(i == widget.indexController.selectedIndex){
      return Colors.red;
    }else{
      return Colors.blue;
    }
  }
}