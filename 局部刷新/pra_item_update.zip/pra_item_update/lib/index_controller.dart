import 'package:flutter/cupertino.dart';


abstract class IndexController {
  factory IndexController.create(State state) => IndexControllerImp(state);

  State get state;

  void setSelectedIndex(int index);

  int get selectedIndex;

  ValueNotifier<List<int>> get indexPosition;

}

class IndexControllerImp implements IndexController {
  State _state;
  @override
  final ValueNotifier<List<int>> indexPosition = ValueNotifier([0,0]);


  IndexControllerImp(State state)
      : _state = state,
        super();

  int _selectedIndex;

  @override
  void setSelectedIndex(int index) {
    int oldSelectedIndex = _selectedIndex;
    if (oldSelectedIndex == null) {
      _selectedIndex = index;
      indexPosition.value = [_selectedIndex,_selectedIndex];
    } else {
      int newSelectedIndex = index;
      if (newSelectedIndex != oldSelectedIndex) {
        _selectedIndex = newSelectedIndex;
        indexPosition.value = [oldSelectedIndex,newSelectedIndex];
      }
    }
  }

  @override
  // TODO: implement selectedIndex
  int get selectedIndex => _selectedIndex;

  @override
  // TODO: implement state
  State<StatefulWidget> get state => _state;

}
