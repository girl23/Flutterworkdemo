import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'index_controller.dart';

// ignore: must_be_immutable
class ItemWidget extends StatefulWidget {
  IndexController _indexController;
  int _index;
  Widget _child;
  int _selectedIndex;

  ItemWidget(
      {Widget child,IndexController indexController, int index, int selectedIndex})
      : _child = child,
        _indexController = indexController,
        _index = index,
        _selectedIndex = selectedIndex;


  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _ItemWidgetState();
  }

}

class _ItemWidgetState extends State<ItemWidget>{
  bool isSelected = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    isSelected = widget._index == widget._selectedIndex;
    widget._indexController?.indexPosition?.addListener(_indexChanged);
  }

  @override
  void dispose() {
    widget._indexController?.indexPosition?.removeListener(_indexChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: isSelected?Colors.red:Colors.blue,
      child: widget._child,
    );
  }


  void _indexChanged(){
    int oldIndex = widget._indexController.indexPosition.value[0];
    int newIndex = widget._indexController.indexPosition.value[1];
    bool newSelected = false;
    if(newIndex == widget._index){
      newSelected = true;
    }
    if(isSelected != newSelected){
      isSelected = newSelected;
      print('setState ${widget._index}');
      setState(() {
      });
    }

  }


}

